<?php
$_SERVER['REQUEST_METHOD'] = 'GET';
$_GET['action'] = 'get_session_profile';
$_GET['session_id'] = '1';
session_start();
$_SESSION['admin_id'] = 1;
require 'adminstrator/api_support_chat.php';
