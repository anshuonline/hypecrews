<?php
// Database configuration
date_default_timezone_set('Asia/Kolkata');
$servername = "localhost";
$username = "u388169091_hypecrewsun";  // Default XAMPP username
$password = "@Hypecrewsdb1";      // Default XAMPP password (empty)
$dbname = "u388169091_hypecrewsdb";

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->exec("SET time_zone = '+05:30'");
    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Track User Activity (Only on user-facing pages, not admin pages)
if (session_status() === PHP_SESSION_ACTIVE && isset($_SESSION['user_id']) && strpos($_SERVER['SCRIPT_NAME'], '/adminstrator/') === false) {
    $user_id = $_SESSION['user_id'];
    $ip = $_SERVER['REMOTE_ADDR'];
    // Rate limit the update to once every 1 minute
    if (!isset($_SESSION['last_activity_update']) || (time() - $_SESSION['last_activity_update']) > 60) {
        $pdo->prepare("UPDATE users SET ip_address = ?, last_active_at = CURRENT_TIMESTAMP WHERE id = ?")->execute([$ip, $user_id]);
        $_SESSION['last_activity_update'] = time();
    }
}

?>




