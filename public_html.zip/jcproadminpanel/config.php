<?php
// PHP errors dekhne ke liye (baad me hata sakte hain)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
date_default_timezone_set('Asia/Kolkata');
// Hostinger Database configuration
$servername = "localhost";
$username = "u388169091_rajdeep"; 
$password = "@Japacounterpro1234.com"; 
$dbname = "u388169091_japacounterpro"; 

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset
$conn->set_charset("utf8mb4");

// Function to check if admin is logged in
function check_auth() {
    if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
        header("Location: index.php");
        exit();
    }
}

$check_bot_col = $conn->query("SHOW COLUMNS FROM users LIKE 'is_bot'");
if ($check_bot_col && $check_bot_col->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN is_bot TINYINT(1) DEFAULT 0");
}

// Add bot_mantra column for admin reference
$check_mantra_col = $conn->query("SHOW COLUMNS FROM users LIKE 'bot_mantra'");
if ($check_mantra_col && $check_mantra_col->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN bot_mantra VARCHAR(100) DEFAULT NULL");
}

// Add ads_disabled column to users table if it doesn't exist
$check_ads_col = $conn->query("SHOW COLUMNS FROM users LIKE 'ads_disabled'");
if ($check_ads_col && $check_ads_col->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN ads_disabled TINYINT(1) DEFAULT 0");
}
// Auto-create app_settings table for Ad config
$conn->query("CREATE TABLE IF NOT EXISTS app_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ads_enabled TINYINT(1) DEFAULT 1,
    admob_interstitial_id VARCHAR(255) DEFAULT 'ca-app-pub-3940256099942544/1033173712',
    admob_rewarded_id VARCHAR(255) DEFAULT 'ca-app-pub-3940256099942544/5354046379',
    admob_app_open_id VARCHAR(255) DEFAULT 'ca-app-pub-3940256099942544/9257395921',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)");

// Insert default settings row if table is empty
$res_settings = $conn->query("SELECT COUNT(*) as cnt FROM app_settings");
if ($res_settings) {
    $row_settings = $res_settings->fetch_assoc();
    if ($row_settings['cnt'] == 0) {
        $conn->query("INSERT INTO app_settings (ads_enabled) VALUES (1)");
    }
}


?>